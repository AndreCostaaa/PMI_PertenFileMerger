merge_all.exe
    	Pour merger tous les documents CSV (prends plus de temps)
merge_latest_date.exe
    	Va detecter automatiquement la dernière date et mergera seulement les données de celle-ci
 
Le script va chercher les données sur \\PMPPSSSQLPRD.PMP.CH.PMI\OutboundMmsPRD et produit un répertoire "CompiledData"
sur le répertoire depuis où le script a été lancé.

